package dev.emccasino.client.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class BlackjackScreen extends BaseCasinoScreen {
    private long betAmount = 50;
    private String status = "BETTING";
    private String result = "NONE";
    private int playerTotal = 0;
    private int dealerTotal = 0;
    private long payout = 0;
    private final List<String> playerCards = new ArrayList<>();
    private final List<String> dealerCards = new ArrayList<>();

    public BlackjackScreen(BlockPos pos, String initialStateJson, long playerBalance) {
        super(Component.literal("Blackjack Table (Pays 3:2)"), pos, initialStateJson, playerBalance);
        this.bgWidth = 340;
        this.bgHeight = 220;
    }

    @Override
    protected void initGameWidgets() {
        onStateUpdated();

        // Bet selectors
        int betY = topPos + 38;
        addRenderableWidget(Button.builder(Component.literal("10"), b -> betAmount = 10).bounds(leftPos + 10, betY, 26, 16).build());
        addRenderableWidget(Button.builder(Component.literal("50"), b -> betAmount = 50).bounds(leftPos + 40, betY, 26, 16).build());
        addRenderableWidget(Button.builder(Component.literal("100"), b -> betAmount = 100).bounds(leftPos + 70, betY, 32, 16).build());
        addRenderableWidget(Button.builder(Component.literal("500"), b -> betAmount = 500).bounds(leftPos + 106, betY, 32, 16).build());

        // Game actions
        int actY = topPos + 160;
        addRenderableWidget(Button.builder(Component.literal("§aDeal"), b -> {
            JsonObject json = new JsonObject();
            json.addProperty("bet", betAmount);
            sendAction("DEAL", GSON.toJson(json));
        }).bounds(leftPos + 10, actY, 55, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Hit"), b -> sendAction("HIT", "{}")).bounds(leftPos + 70, actY, 50, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Stand"), b -> sendAction("STAND", "{}")).bounds(leftPos + 125, actY, 55, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Double"), b -> sendAction("DOUBLE", "{}")).bounds(leftPos + 185, actY, 60, 20).build());
    }

    @Override
    protected void onStateUpdated() {
        try {
            JsonObject obj = GSON.fromJson(lastStateJson, JsonObject.class);
            if (obj != null) {
                if (obj.has("status")) this.status = obj.get("status").getAsString();
                if (obj.has("result")) this.result = obj.get("result").getAsString();
                if (obj.has("playerTotal")) this.playerTotal = obj.get("playerTotal").getAsInt();
                if (obj.has("dealerTotal")) this.dealerTotal = obj.get("dealerTotal").getAsInt();
                if (obj.has("payout")) this.payout = obj.get("payout").getAsLong();

                playerCards.clear();
                if (obj.has("playerCards")) {
                    for (var el : obj.getAsJsonArray("playerCards")) playerCards.add(el.getAsString());
                }
                dealerCards.clear();
                if (obj.has("dealerCards")) {
                    for (var el : obj.getAsJsonArray("dealerCards")) dealerCards.add(el.getAsString());
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void renderGameContent(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        extractor.text(this.font, "Current Bet: §e" + betAmount + " EMC", leftPos + 150, topPos + 42, COLOR_TEXT_WHITE);

        // Dealer Section
        int dY = topPos + 60;
        extractor.text(this.font, "Dealer (" + dealerTotal + "):", leftPos + 12, dY + 8, COLOR_TEXT_GOLD);
        for (int i = 0; i < dealerCards.size(); i++) {
            drawCard(extractor, leftPos + 90 + (i * 26), dY, dealerCards.get(i));
        }

        // Player Section
        int pY = topPos + 105;
        extractor.text(this.font, "Player (" + playerTotal + "):", leftPos + 12, pY + 8, COLOR_TEXT_GOLD);
        for (int i = 0; i < playerCards.size(); i++) {
            drawCard(extractor, leftPos + 90 + (i * 26), pY, playerCards.get(i));
        }

        // Result Banner
        if (!"NONE".equals(result)) {
            String banner;
            int color;
            switch (result) {
                case "BLACKJACK" -> { banner = "★ BLACKJACK! Won " + payout + " EMC ★"; color = COLOR_TEXT_GREEN; }
                case "PLAYER_WIN", "DEALER_BUST" -> { banner = "YOU WON! +" + payout + " EMC"; color = COLOR_TEXT_GREEN; }
                case "PUSH" -> { banner = "PUSH (Tie) - Bet returned"; color = COLOR_TEXT_GOLD; }
                case "PLAYER_BUST" -> { banner = "BUSTED! Lost bet"; color = COLOR_TEXT_RED; }
                default -> { banner = "Dealer Wins"; color = COLOR_TEXT_RED; }
            }
            extractor.centeredText(this.font, banner, leftPos + bgWidth / 2, topPos + 144, color);
        }
    }
}
